#pragma once

class UIObject;

class ButtonComponent
{
public:
	bool CheckIsCliked(UIObject& uiObject, int x, int y);
};

