#include "CursorInputComponent.h"
#include "GameObject.h"

void CursorInputComponent::Update(GameObject & gameObject)
{

}
